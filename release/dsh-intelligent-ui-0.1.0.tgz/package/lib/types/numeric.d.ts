/**
 * Conservative cell parsing for charts. A column is plottable only when every
 * non-missing cell is a plain number with the same unit; anything unclear
 * keeps the column table-only. Display always uses the original cell text.
 */
/** One classified table cell. */
export type CellValue = {
    readonly kind: 'missing';
} | {
    readonly kind: 'number';
    readonly value: number;
    readonly unit: string;
} | {
    readonly kind: 'text';
};
/**
 * Classify one cell.
 * @param raw - cell text as shown in the answer.
 * @returns missing, a number with its unit, or text (including unsafe precision).
 */
export declare function parseCell(raw: string): CellValue;
/** What one column can be used for. */
export interface ColumnAnalysis {
    /** Same-unit numeric series, or null when the column is not plottable. */
    readonly numeric: {
        readonly unit: string;
        readonly values: readonly (number | null)[];
    } | null;
    /** Every cell present: usable as the category/time axis. */
    readonly categorical: boolean;
}
/**
 * Analyze one column's cells.
 * @param cells - the column's cell texts, in row order.
 * @returns plottability and axis suitability.
 */
export declare function analyzeColumn(cells: readonly string[]): ColumnAnalysis;
/**
 * Human-readable unit from an internal `prefix|suffix` key.
 * @param unit - internal unit key.
 * @returns the symbol to show beside axis values, or ''.
 */
export declare function displayUnit(unit: string): string;
//# sourceMappingURL=numeric.d.ts.map